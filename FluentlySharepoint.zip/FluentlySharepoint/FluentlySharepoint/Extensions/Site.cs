﻿using Microsoft.SharePoint.Client;

namespace FluentlySharepoint.Extensions
{
	public static class Site
	{
		public static WebTemplateCollection GetWebTemplates(this CSOMOperation operation, uint lcid, bool overrideCompatibilityLevel = false)
		{
			var collection = operation.LastSite.GetWebTemplates(lcid, overrideCompatibilityLevel ? 1 : 0);
			operation.Context.ExecuteQuery();

			return collection;
		}
	}
}