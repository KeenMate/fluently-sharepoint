﻿namespace FluentlySharepoint
{
	public enum OperationLevels
	{
		Web,
		Site,
		List
	}
}