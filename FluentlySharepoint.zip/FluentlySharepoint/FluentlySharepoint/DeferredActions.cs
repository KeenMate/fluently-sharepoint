﻿namespace FluentlySharepoint
{
	public enum DeferredActions
	{
		Load,
		Delete
	}
}