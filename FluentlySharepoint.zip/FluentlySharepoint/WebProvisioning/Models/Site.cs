﻿using System.Collections.Generic;

namespace WebProvisioning.Models
{
	public class Site
	{
		public List<Web> Webs { get; set; }
	}
}