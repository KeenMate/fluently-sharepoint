using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

#if DEBUG
[assembly: AssemblyConfiguration("Debug")]
#else
 [assembly: AssemblyConfiguration("Release")]
#endif
[assembly: AssemblyCompany("KEEN|MATE")]
[assembly: AssemblyProduct("fluently-sharepoint")]
[assembly: AssemblyCopyright("Copyright � KEEN|MATE 2017")]
[assembly: AssemblyTrademark("")]